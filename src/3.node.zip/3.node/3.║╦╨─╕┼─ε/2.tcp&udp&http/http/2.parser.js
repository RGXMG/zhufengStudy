/**
 * parser解析请求对象，其实就是socket.(data)拿到的信息，
 * 然后解析出请求头，再传给请求监听函数
 */
function parser() {

}

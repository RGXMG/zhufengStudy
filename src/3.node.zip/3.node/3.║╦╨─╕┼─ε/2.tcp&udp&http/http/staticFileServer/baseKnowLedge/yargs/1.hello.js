// process.argv 中从第三个元素开始保存命令行时传入的参数
// 第一个元素是自身node的执行程序、第二个元素是当前执行的程序的路径
console.log(process.argv[2]);
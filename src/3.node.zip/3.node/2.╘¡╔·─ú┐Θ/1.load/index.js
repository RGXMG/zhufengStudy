const a = require('./load');
console.log(a);
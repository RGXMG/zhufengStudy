// 类型断言
// arg1: 为真，什么都不发生
// arg2: 为假，报错
// 通常用作单元测试
console.assert(1 === 1, 'error');

// 全部对象属性
// 输出一个对象的所有属性，复杂度对象的时候不缩写成[Object]
console.dir(global);

// 追踪执行栈
// console.trace();

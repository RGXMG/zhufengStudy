module.exports = { a: 'oneOfModule' };
console.log(module);
console.log('我是6.oneOfModule');